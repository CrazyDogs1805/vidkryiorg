var footer = document.getElementsByClassName('nav_footer');

footer.innerHTML = '<div class="nav_footer"><ul class="col-xs-4 col-md-3"><li class=""><a href="gospel.html">Євангеліє</a></li><li class=""><a href="evidence.html" >Докази</a></li><li class=""><a href="articles.html" >Статті</a></li><li class=""><a href="about.html" >Про проект</a></li><li><a href="questions.html">Запитання</a></li></ul><ul class="col-xs-4 col-md-3"><li><a href="https://www.facebook.com/ccx.ukraine">Facebook</a></li><li><a href="https://vk.com/ccx.ukraine">Vkontakte</a></li></ul><ul class="col-xs-12 col-md-3"><li class="copyright"><span>Дизайн і розробка -</span><a href="#">CHEESEBANANA</a></li></ul></div>'

console.log(footer);